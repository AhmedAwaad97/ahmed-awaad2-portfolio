export default function About() {
  return (
    <section id="about" className="py-20 bg-slate-800/50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-8">
          About{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Me
          </span>
        </h2>

        <div className="bg-slate-900/50 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-8 hover:border-cyan-500/40 transition-all duration-300">
          <p className="text-gray-300 text-lg leading-relaxed">
            I am a Senior Accountant with 5+ years (2019‑present) of experience in accounting,
            financial reporting and data analytics. I combine accounting best practices with Power
            BI, DAX, Power Query and advanced Excel to build automated reporting, KPI dashboards and
            profitability analyses that support strategic decisions.
          </p>
        </div>
      </div>
    </section>
  );
}
