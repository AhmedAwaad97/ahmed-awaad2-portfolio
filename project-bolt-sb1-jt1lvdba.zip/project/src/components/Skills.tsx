import {
  BarChart3,
  Table,
  Code,
  Calculator,
  Database,
  FileText,
  Server,
} from 'lucide-react';

const skills = [
  {
    icon: BarChart3,
    name: 'Power BI',
    detail: 'Dashboarding',
  },
  {
    icon: Table,
    name: 'Advanced Excel',
    detail: 'Data Analysis',
  },
  {
    icon: Code,
    name: 'DAX & Power Query',
    detail: 'Data Transformation',
  },
  {
    icon: Calculator,
    name: 'Financial Analysis',
    detail: 'Reporting',
  },
  {
    icon: Database,
    name: 'Data Modeling',
    detail: 'ETL Processes',
  },
  {
    icon: FileText,
    name: 'Accounting',
    detail: 'Financial Reporting',
  },
  {
    icon: Server,
    name: 'ERP Systems',
    detail: 'Dynamics 365, AX',
  },
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-12">
          Skills &{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Expertise
          </span>
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => {
            const Icon = skill.icon;
            return (
              <div
                key={index}
                className="group bg-slate-800/50 backdrop-blur-sm border border-cyan-500/20 rounded-xl p-6 hover:border-cyan-500/50 hover:bg-slate-800/70 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/10"
              >
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className="p-3 bg-cyan-500/10 rounded-lg group-hover:bg-cyan-500/20 transition-colors">
                    <Icon className="w-8 h-8 text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">{skill.name}</h3>
                    <p className="text-sm text-gray-400">{skill.detail}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
