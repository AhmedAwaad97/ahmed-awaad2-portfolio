import { Github } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 border-t border-cyan-500/20 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-gray-400 text-sm">
          <p>© {currentYear} Ahmed Mahmoud Awaad. All Rights Reserved.</p>
          <span className="hidden sm:inline">•</span>
          <a
            href="https://github.com/AhmedAwaad97/ahmed-awaad2-portfolio"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <Github size={16} />
            <span>View on GitHub</span>
          </a>
        </div>
      </div>
    </footer>
  );
}
