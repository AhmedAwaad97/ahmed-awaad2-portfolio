import { Briefcase, Calendar } from 'lucide-react';

const experiences = [
  {
    title: 'Senior Accountant',
    company: 'Deraah Trading Company',
    industry: 'Perfumes, Cosmetics & Accessories - KSA',
    period: '03/2025 – Present',
    responsibilities: [
      'Manage bank operations and reconcile daily/monthly statements',
      'Match showroom deposits with accounting records and prepare reconciliation reports',
      'Reconcile installment reports from Tamara and Tabby platforms',
      'Record journal entries and manage accounts receivable/payable using ERP systems',
      'Collaborate with procurement and operations departments for financial accuracy',
    ],
  },
  {
    title: 'Senior Accountant',
    company: 'Integrated Technics',
    industry: 'System Integrator (Security & ICT solutions)',
    period: '12/2022 – 03/2025',
    responsibilities: [
      'Updated accounts payable and established accounting program database',
      'Managed project follow-ups with suppliers, customers, and cross-functional teams',
      'Assisted with audits, tax preparations, and financial report analysis',
      'Prepared financial reports for regulatory bodies and shareholders',
      'Supported month-end and year-end closings and general ledger management',
    ],
  },
  {
    title: 'Senior Accountant',
    company: 'Tawreda.com',
    industry: 'HORECA Food Supply - Cairo, Egypt',
    period: '02/2020 – 06/2021',
    responsibilities: [
      'Maintained daily accounts and prepared month-end close',
      'Prepared monthly financial performance reports and management information',
      'Conducted credit control, debt collection, and accounts receivable/payable oversight',
      'Reviewed expenses, payroll records, and updated financial data',
      'Facilitated month-end closing process and transaction reconciliation',
    ],
  },
  {
    title: 'General Accountant',
    company: 'Cattelya For Chemical Co',
    industry: '',
    period: '07/2019 – 02/2020',
    responsibilities: [
      'Prepared and recorded journal entries and assisted with expense reviews',
      'Aided in financial statement preparation and bank reconciliation',
      'Maintained fixed assets register and calculated depreciation',
      'Managed online banking transactions and monitored daily cash balances',
    ],
  },
];

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-slate-800/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-12">
          Professional{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Experience
          </span>
        </h2>

        <div className="space-y-6">
          {experiences.map((exp, index) => (
            <div
              key={index}
              className="bg-slate-900/50 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-6 sm:p-8 hover:border-cyan-500/40 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10"
            >
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                <div className="flex-1">
                  <div className="flex items-start gap-3 mb-2">
                    <div className="p-2 bg-cyan-500/10 rounded-lg mt-1">
                      <Briefcase className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-cyan-400">{exp.title}</h3>
                      <p className="text-white font-semibold mt-1">{exp.company}</p>
                      {exp.industry && (
                        <p className="text-gray-400 text-sm italic mt-1">{exp.industry}</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-gray-400 text-sm sm:text-base whitespace-nowrap">
                  <Calendar size={16} />
                  <span>{exp.period}</span>
                </div>
              </div>

              <ul className="space-y-2 ml-14">
                {exp.responsibilities.map((resp, idx) => (
                  <li key={idx} className="text-gray-300 flex items-start gap-2">
                    <span className="text-cyan-400 mt-1.5 flex-shrink-0">•</span>
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
