import { FileSpreadsheet, Download, FileText } from 'lucide-react';

const projects = [
  {
    icon: FileSpreadsheet,
    title: 'Income Statement Report',
    description:
      'A comprehensive Power BI income statement report that provides detailed financial performance analysis. Features revenue and expense tracking, profit margin analysis, and period-over-period comparisons for informed financial decision-making.',
    tags: ['Power BI', 'Financial Reporting', 'Income Statement', 'Profit & Loss', 'DAX'],
    fileUrl:
      'https://raw.githubusercontent.com/AhmedAwaad97/ahmed-awaad2-portfolio/main/Income%20Statement%20Report.pbix',
    fileName: 'Income Statement Report.pbix',
    fileSize: '2.8 MB',
  },
  {
    icon: FileSpreadsheet,
    title: 'Car Sales Dashboard',
    description:
      'A dynamic Power BI dashboard that presents key KPIs such as total sales, average car price, and car sales performance by year and month. It also includes advanced DAX time intelligence measures for deeper insights into sales trends and patterns.',
    tags: ['Power BI', 'Dashboard', 'Sales Analysis', 'DAX', 'Time Intelligence'],
    fileUrl:
      'https://raw.githubusercontent.com/AhmedAwaad97/ahmed-awaad2-portfolio/main/Car%20Sales%20Dashboard.pbix',
    fileName: 'Car Sales Dashboard.pbix',
    fileSize: '2.5 MB',
  },
  {
    icon: FileSpreadsheet,
    title: 'Sales & Profit Dashboard',
    description:
      'Comprehensive Power BI dashboard analyzing sales performance, profit margins, and key business metrics. Features interactive filtering, trend analysis, and performance indicators to track business health.',
    tags: ['Power BI', 'Dashboard', 'Sales Analysis', 'Profitability'],
    fileUrl:
      'https://raw.githubusercontent.com/AhmedAwaad97/ahmed-awaad2-portfolio/main/Sales%20%26%20Profit%20Dashboard.pbix',
    fileName: 'Sales & Profit Dashboard.pbix',
    fileSize: '3.2 MB',
  },
  {
    icon: FileSpreadsheet,
    title: 'Sales Performance Dashboard',
    description:
      'Interactive Power BI dashboard tracking sales performance metrics, regional comparisons, and sales team productivity. Includes drill-down capabilities and time-series analysis for detailed insights.',
    tags: ['Power BI', 'Dashboard', 'Performance', 'Regional Analysis'],
    fileUrl:
      'https://raw.githubusercontent.com/AhmedAwaad97/ahmed-awaad2-portfolio/main/Sales%20Performance%20Dashboard.pbix',
    fileName: 'Sales Performance Dashboard.pbix',
    fileSize: '2.8 MB',
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 bg-slate-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
          Power BI{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Projects
          </span>
        </h2>
        <p className="text-gray-400 mb-12 max-w-3xl">
          Explore my Power BI dashboards and reports that showcase my data analysis and
          visualization capabilities.
        </p>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => {
            const Icon = project.icon;
            return (
              <div
                key={index}
                className="bg-slate-900/50 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-8 hover:border-cyan-500/40 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10 flex flex-col"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-cyan-500/10 rounded-lg flex-shrink-0">
                    <Icon className="w-8 h-8 text-cyan-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white">{project.title}</h3>
                </div>

                <p className="text-gray-300 mb-4 flex-grow leading-relaxed">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1 bg-cyan-500/10 text-cyan-400 text-sm rounded-full border border-cyan-500/30"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 pt-4 border-t border-cyan-500/20">
                  <a
                    href={project.fileUrl}
                    download={project.fileName}
                    className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-lg hover:from-cyan-400 hover:to-blue-400 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/20"
                  >
                    <Download size={18} />
                    <span>Download Dashboard</span>
                  </a>

                  <div className="flex items-center gap-2 text-gray-400 text-sm">
                    <FileText size={16} />
                    <span>
                      .pbix • {project.fileSize}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
