import { Award } from 'lucide-react';

const certifications = [
  {
    title: 'Power BI & Excel Data Analysis',
    description:
      'Certified in advanced Power BI, Power Query and Excel techniques for financial analysis and reporting.',
  },
  {
    title: 'Qualified Accountant Diploma',
    description:
      'Professional qualification focused on financial reporting, analysis and accounting standards.',
  },
];

export default function Certifications() {
  return (
    <section id="certifications" className="py-20 bg-slate-900">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-12">
          Certifications &{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Qualifications
          </span>
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          {certifications.map((cert, index) => (
            <div
              key={index}
              className="bg-slate-800/50 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-8 hover:border-cyan-500/40 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-cyan-500/10 rounded-lg flex-shrink-0">
                  <Award className="w-7 h-7 text-cyan-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-cyan-400 mb-3">{cert.title}</h3>
                  <p className="text-gray-300 leading-relaxed">{cert.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
