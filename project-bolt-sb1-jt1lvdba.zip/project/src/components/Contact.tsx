import { useState, FormEvent } from 'react';
import { Mail, Phone, Linkedin, Github, Send, Loader2 } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [status, setStatus] = useState<{
    type: 'idle' | 'loading' | 'success' | 'error';
    message: string;
  }>({ type: 'idle', message: '' });

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus({ type: 'error', message: 'Please fill in all fields.' });
      return;
    }

    if (formData.message.length < 10) {
      setStatus({
        type: 'error',
        message: 'Please write a more detailed message (at least 10 characters).',
      });
      return;
    }

    setStatus({ type: 'loading', message: 'Sending your message...' });

    try {
      const response = await fetch('https://formspree.io/f/xrbynngg', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: formData.message,
          _subject: 'New Portfolio Contact Form Submission',
        }),
      });

      if (response.ok) {
        setStatus({
          type: 'success',
          message: 'Thank you! Your message has been sent successfully. I will reply shortly.',
        });
        setFormData({ name: '', email: '', message: '' });

        setTimeout(() => {
          setStatus({ type: 'idle', message: '' });
        }, 8000);
      } else {
        throw new Error('Form submission failed');
      }
    } catch (error) {
      setStatus({
        type: 'error',
        message: 'Failed to send message. Please try again or contact me directly.',
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (status.type === 'error') {
      setStatus({ type: 'idle', message: '' });
    }
  };

  return (
    <section id="contact" className="py-20 bg-slate-900">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-12">
          Get In{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Touch
          </span>
        </h2>

        <div className="grid lg:grid-cols-5 gap-12">
          <div className="lg:col-span-3">
            <form
              onSubmit={handleSubmit}
              className="bg-slate-800/50 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-8 space-y-6"
            >
              <div>
                <label htmlFor="name" className="block text-gray-300 font-medium mb-2">
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900 border border-cyan-500/30 rounded-lg text-white focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                  placeholder="Your name"
                  required
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-gray-300 font-medium mb-2">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900 border border-cyan-500/30 rounded-lg text-white focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                  placeholder="your.email@example.com"
                  required
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-gray-300 font-medium mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  rows={5}
                  className="w-full px-4 py-3 bg-slate-900 border border-cyan-500/30 rounded-lg text-white focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition-all resize-vertical"
                  placeholder="Your message..."
                  required
                />
                <p className="text-gray-400 text-sm mt-1">{formData.message.length}/1000</p>
              </div>

              <button
                type="submit"
                disabled={status.type === 'loading'}
                className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-lg hover:from-cyan-400 hover:to-blue-400 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
              >
                {status.type === 'loading' ? (
                  <>
                    <Loader2 size={18} className="animate-spin" />
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Send size={18} />
                    <span>Send Message</span>
                  </>
                )}
              </button>

              {status.message && (
                <div
                  className={`p-4 rounded-lg border ${
                    status.type === 'success'
                      ? 'bg-green-500/10 border-green-500/30 text-green-400'
                      : status.type === 'error'
                      ? 'bg-red-500/10 border-red-500/30 text-red-400'
                      : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
                  }`}
                >
                  {status.message}
                </div>
              )}
            </form>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-800/50 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Contact Information</h3>

              <div className="space-y-4">
                <a
                  href="mailto:Ahmedawwad01097903539@gmail.com"
                  className="flex items-start gap-3 text-gray-300 hover:text-cyan-400 transition-colors group"
                >
                  <div className="p-2 bg-cyan-500/10 rounded-lg group-hover:bg-cyan-500/20 transition-colors">
                    <Mail size={20} className="text-cyan-400" />
                  </div>
                  <div>
                    <p className="font-medium text-white mb-1">Email</p>
                    <p className="text-sm break-all">Ahmedawwad01097903539@gmail.com</p>
                  </div>
                </a>

                <a
                  href="tel:+966569237463"
                  className="flex items-start gap-3 text-gray-300 hover:text-cyan-400 transition-colors group"
                >
                  <div className="p-2 bg-cyan-500/10 rounded-lg group-hover:bg-cyan-500/20 transition-colors">
                    <Phone size={20} className="text-cyan-400" />
                  </div>
                  <div>
                    <p className="font-medium text-white mb-1">Phone (KSA)</p>
                    <p className="text-sm">+966 56 923 7463</p>
                  </div>
                </a>

                <a
                  href="tel:+0201097903539"
                  className="flex items-start gap-3 text-gray-300 hover:text-cyan-400 transition-colors group"
                >
                  <div className="p-2 bg-cyan-500/10 rounded-lg group-hover:bg-cyan-500/20 transition-colors">
                    <Phone size={20} className="text-cyan-400" />
                  </div>
                  <div>
                    <p className="font-medium text-white mb-1">Phone (Egypt)</p>
                    <p className="text-sm">+20 0109 790 3539</p>
                  </div>
                </a>
              </div>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Connect With Me</h3>

              <div className="flex flex-col gap-3">
                <a
                  href="https://www.linkedin.com/in/ahmed-m-awaad-59103b167/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 px-4 py-3 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-lg transition-all duration-300 hover:scale-105 text-white"
                >
                  <Linkedin size={20} className="text-cyan-400" />
                  <span>LinkedIn</span>
                </a>

                <a
                  href="https://github.com/AhmedAwaad97/ahmed-awaad2-portfolio"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 px-4 py-3 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-lg transition-all duration-300 hover:scale-105 text-white"
                >
                  <Github size={20} className="text-cyan-400" />
                  <span>GitHub</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
