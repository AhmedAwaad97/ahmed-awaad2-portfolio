import { Mail, Phone } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>

      <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/10 via-transparent to-transparent"></div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <div className="animate-fade-in">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-4">
            Ahmed Mahmoud{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
              Awaad
            </span>
          </h1>

          <h2 className="text-xl sm:text-2xl text-gray-300 font-medium mb-6">
            Senior Accountant & Power BI Data Analyst
          </h2>

          <p className="text-base sm:text-lg text-gray-400 max-w-3xl mx-auto leading-relaxed mb-8">
            Transforming financial and operational data into clear insights. I design Power BI
            reports, automate reporting with Power Query & Excel, and produce management-ready
            financial analysis.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-gray-300">
            <a
              href="mailto:Ahmedawwad01097903539@gmail.com"
              className="flex items-center gap-2 px-6 py-3 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-lg transition-all duration-300 hover:scale-105"
            >
              <Mail size={20} className="text-cyan-400" />
              <span className="text-sm">Ahmedawwad01097903539@gmail.com</span>
            </a>

            <a
              href="tel:+966569237463"
              className="flex items-center gap-2 px-6 py-3 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-lg transition-all duration-300 hover:scale-105"
            >
              <Phone size={20} className="text-cyan-400" />
              <span className="text-sm">+966 56 923 7463</span>
            </a>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <a href="#about" className="text-cyan-400 hover:text-cyan-300">
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        </a>
      </div>
    </section>
  );
}
